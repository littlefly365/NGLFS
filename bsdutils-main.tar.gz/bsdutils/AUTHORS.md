- Daniel Kolesa <daniel@octaforge.org>

- Dave Cantrell <dcantrell@burdell.org>

- James Bair <tsuehpsyde@gmail.com>
