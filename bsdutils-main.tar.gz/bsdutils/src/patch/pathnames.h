/*-
 * Placed in the public domain by Todd C. Miller <Todd.Miller@courtesan.com>
 * on July 29, 2003.
 *
 * $OpenBSD: pathnames.h,v 1.1 2003/07/29 20:10:17 millert Exp $
 */


#include <paths.h>

#define	_PATH_RED		"/bin/red"
